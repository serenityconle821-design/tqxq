document.getElementById('extractBtn').addEventListener('click', async () => {
  const btn = document.getElementById('extractBtn');
  const status = document.getElementById('status');
  btn.disabled = true;
  status.innerText = '正在执行严格无格式导出...';

  try {
    let tabs = await chrome.tabs.query({ url: ["*://*.amazon.com/*", "*://*.amazon.co.uk/*", "*://*.amazon.de/*", "*://*.amazon.co.jp/*", "*://*.amazon.ca/*"] });
    if (tabs.length === 0) throw new Error("未检测到已打开的亚马逊页面");

    let results = [];
    for (let tab of tabs) {
      try {
        let injection = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: () => {
            const match = location.href.match(/(?:dp|o|ASIN|product-reviews)[/]([a-zA-Z0-9]{10})/i);
            const asin = match ? match[1] : "未知";

            const titleE = document.querySelector('#productTitle, h1.a-size-large, span#productTitle');
            const title = titleE ? titleE.innerText.trim() : document.title.split(':')[0].trim();

            let bulletSet = new Set();
            let rankSet = new Set();
            
            let coreContainer = document.querySelector('#centerCol') || document.querySelector('#desktop_feature_bullets') || document.querySelector('#aboutThisItem');
            
            if (coreContainer) {
                coreContainer.querySelectorAll('ul.a-unordered-list li, div#feature-bullets ul li, div#aboutThisItem ul li').forEach(li => {
                    let text = li.innerText.trim();
                    if (text.length < 5 || li.closest('.a-hidden') || text.includes("Make sure this fits") || text.includes("Add to Cart") || text.includes("clickstream") || text.includes('{"') || text.includes("<img")) return;

                    if (/#\d+(?:,\d+)*\s+in\s+/i.test(text)) {
                        let cleanRank = text.replace(/\(See Top 100[^\)]+\)/gi, '').trim();
                        rankSet.add(cleanRank);
                    } else if (/(?:^\$\d+|\d+\s*percent savings|%\s*off)/i.test(text)) {
                        return; // 静默剔除价格
                    } else if (text.length > 15) {
                        bulletSet.add(text);
                    }
                });
            }

            if (rankSet.size === 0) {
                let r = document.querySelector('#salesRank, #SalesRank');
                if (r) {
                    let rText = r.innerText.replace(/\s+/g, ' ').trim();
                    let matches = rText.match(/#\d+(?:,\d+)*\s+in\s+[^\(]+/g);
                    if (matches) {
                        matches.forEach(m => {
                            let cleanM = m.replace(/\(See Top 100[^\)]+\)/gi, '').trim();
                            rankSet.add(cleanM);
                        });
                    }
                }
            }

            let colorSet = new Set();
            document.querySelectorAll('img.imgSwatch, #variation_color_name img, .swatch-image, img.variation-color-image').forEach(img => {
                let alt = img.getAttribute('alt');
                let parentLi = img.closest('li');
                let isUnavailable = parentLi && (parentLi.classList.contains('swatchUnavailable') || parentLi.classList.contains('unavailable') || parentLi.classList.contains('inline-twister-dimmed'));
                if (alt && !isUnavailable) colorSet.add(alt.trim());
            });
            document.querySelectorAll('select[name="dropdown_selection_color_name"] option, select[id*="color_name"] option').forEach(opt => {
                if (!opt.disabled && opt.value !== "-1" && !opt.innerText.includes("Select")) {
                    colorSet.add(opt.innerText.trim());
                }
            });
            if (colorSet.size === 0) {
                let single = document.querySelector('#variation_color_name .selection, #twister-plus-selected-color-name');
                if (single && single.innerText.trim()) colorSet.add(single.innerText.trim());
            }

            // 此处直接返回数组，在后续生成 HTML 时注入 Office 原生换行符
            return { 
                asin, 
                title, 
                ranks: Array.from(rankSet), 
                bullets: Array.from(bulletSet), 
                colors: Array.from(colorSet), 
                url: location.href.split('?')[0] 
            };
          }
        });
        if (injection && injection[0] && injection[0].result) results.push(injection[0].result);
      } catch (e) {}
    }

    if (results.length === 0) throw new Error("页面无响应");

    const escapeHtml = (unsafe) => {
        return (unsafe || "").toString().replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    };

    // 构建绝对纯净的骨架，去除所有线条和色彩
    let tableHtml = `
    <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
    <head>
        <meta charset="UTF-8">
        <style>
            table { border-collapse: collapse; font-family: "PingFang SC", "Microsoft YaHei", sans-serif; table-layout: fixed; width: 1200px; }
            th, td { border: none; background: none; vertical-align: middle; padding: 6px; white-space: normal; word-wrap: break-word; font-size: 11pt; }
            th { font-weight: bold; text-align: center; }
            .text-center { text-align: center; }
            .text-left { text-align: left; }
            a { color: #0000ff; text-decoration: underline; }
            
            /* 列宽限制，触发正常换行 */
            .col-asin { width: 100px; }
            .col-rank { width: 220px; }
            .col-title { width: 180px; }
            .col-bullets { width: 500px; }
            .col-colors { width: 120px; }
            .col-url { width: 80px; }
        </style>
    </head>
    <body>
        <table>
            <tr>
                <th class="col-asin">ASIN</th>
                <th class="col-rank">类目排名</th>
                <th class="col-title">商品标题</th>
                <th class="col-bullets">五点描述</th>
                <th class="col-colors">在售颜色</th>
                <th class="col-url">直达链接</th>
            </tr>`;

    // Office 原生同单元格换行符 (等同于 Alt+Enter)
    const excelBr = '<br style="mso-data-placement:same-cell;">';

    results.forEach(r => {
        let safeAsin = escapeHtml(r.asin);
        let safeTitle = escapeHtml(r.title);
        let safeUrl = escapeHtml(r.url);
        
        // 渲染数据时强制插入 WPS 可识别的原生换行符
        let safeRanks = r.ranks.length > 0 ? r.ranks.map(escapeHtml).join(excelBr) : "未获取";
        let safeBullets = r.bullets.length > 0 ? r.bullets.map(escapeHtml).join(excelBr) : "无描述";
        let safeColors = r.colors.length > 0 ? r.colors.map(escapeHtml).join(excelBr) : "未识别";

        tableHtml += `
            <tr>
                <td class="text-center" style="mso-number-format:'\\@';">${safeAsin}</td>
                <td class="text-center">${safeRanks}</td>
                <td class="text-center">${safeTitle}</td>
                <td class="text-left">${safeBullets}</td>
                <td class="text-center">${safeColors}</td>
                <td class="text-center"><a href="${safeUrl}" target="_blank">链接</a></td>
            </tr>`;
    });

    tableHtml += `</table></body></html>`;

    let blob = new Blob([tableHtml], { type: 'application/vnd.ms-excel;charset=utf-8;' });
    let blobUrl = URL.createObjectURL(blob);
    
    chrome.downloads.download({
        url: blobUrl,
        filename: `Amazon_Clean_Data_${Date.now()}.xls`,
        saveAs: false 
    }, () => {
        URL.revokeObjectURL(blobUrl);
    });

    status.innerText = `完全复刻导出完毕 (${results.length} 条)`;
    status.style.color = "#34c759";
  } catch (err) {
    status.innerText = "错误: " + err.message;
    status.style.color = "#ff3b30";
  } finally {
    btn.disabled = false;
  }
});